# Stella Chat Website

A fresh, responsive chat-only website for Stella. It intentionally has **no tummy/display preview**. The ESP32 and OLED screens are separate hardware controlled by firmware.

## Included
- Responsive chat interface
- Phone/browser microphone input through Web Speech API where supported
- Browser-native text-to-speech for spoken replies
- Backend `/api/chat` endpoint using an OpenAI-compatible Chat Completions API
- API key stays server-side in `.env`
- Friendly error message when API configuration is missing
- No external microphone requirement

## Requirements
- Node.js 20+ recommended
- npm

## Run locally
1. Extract this folder and open it in VS Code.
2. In the terminal, run `npm install`.
3. Copy `.env.example` to `.env`.
4. If you have a compatible API key, set `AI_API_KEY` in `.env` and adjust `AI_BASE_URL` / `AI_MODEL` if needed. Never paste the key into frontend code or commit `.env`.
5. Run `npm run dev`.
6. Open `http://localhost:5173`.

The frontend runs on port 5173 and proxies `/api` calls to the backend on port 3001.

### Without an API key
The website and voice controls can still be tested, but sending a chat message will show a clear configuration message instead of generating an AI answer. This avoids pretending that AI is working without a provider.

## Voice behavior
- **Input:** microphone access via browser speech recognition (typically available in Chrome/Edge; support varies by browser and device). The website asks for permission when you tap the microphone. It converts speech to text in the browser's speech recognition service; browser/vendor behavior and network requirements can vary.
- **Output:** `SpeechSynthesisUtterance` uses the device/browser's built-in voices. The Settings panel and speaker buttons control spoken replies.
- If speech recognition is unavailable, type into the chat. The app does not record from an external mic.

## Backend API contract
`POST /api/chat`
```json
{
  "messages": [
    {"role": "user", "content": "Explain binary search"}
  ]
}
```
Success:
```json
{"reply": "Binary search ..."}
```
Errors return `{ "error": "..." }`.

`GET /api/health` returns `{ "ok": true, "service": "stella-api" }`.

## Hardware integration later
The chat website currently does not connect to an ESP32. Later, add a separate ESP32 communication layer (for example, HTTP/WebSocket over Wi-Fi) to send states such as `LISTENING`, `THINKING`, and `SPEAKING`. Keep the website/backend separate from the ESP32 Arduino firmware.
