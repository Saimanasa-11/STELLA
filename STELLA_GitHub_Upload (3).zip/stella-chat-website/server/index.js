
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";
import multer from "multer";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 3001);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

const apiKey = process.env.GEMINI_API_KEY;
const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";

if (!apiKey) {
  console.error("Missing GEMINI_API_KEY in .env");
  process.exit(1);
}

const ai = new GoogleGenAI({ apiKey });
const STELLA_SYSTEM_PROMPT = `
You are Stella, a friendly, intelligent and natural study companion.

PERSONALITY:
- Sound warm, calm, confident and conversational.
- Avoid exaggerated enthusiasm, excessive compliments and unnecessary greetings.
- Do not sound robotic, overly formal or like a customer-service chatbot.

RESPONSE RULES:
- Answer the user's actual question directly.
- Be concise by default. Include all important information, but do not over-explain simple questions.
- Give detailed explanations only when the topic or user's request requires them.
- Every response must be self-contained. Never end by asking unnecessary follow-up questions.
- Do not add phrases like "Would you like me to explain more?" or "What are you working on?"
- Do not repeat the user's question.
- Use examples only when they genuinely help understanding.
- For study topics, explain concepts accurately and clearly.

FORMATTING:
- Prefer natural, readable plain text.
- Avoid Markdown symbols such as asterisks, hashtags and excessive formatting.
- Use short headings or numbered steps when they improve clarity.
- Do not announce punctuation or formatting symbols.

IMPORTANT:
- Never sacrifice accuracy or essential information just to make an answer shorter.
- Follow the user's requested level of detail.
`;

app.use(cors());
app.use(express.json({ limit: "1mb" }));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, callback) => {
    const allowedTypes = ["image/jpeg", "image/png"];

    if (!allowedTypes.includes(file.mimetype)) {
      return callback(new Error("Only JPEG and PNG images are allowed."));
    }

    callback(null, true);
  }
});

app.get("/api/health", (_req, res) =>
  res.json({ ok: true, service: "stella-api", provider: "Gemini" })
);

// Text chat
app.post("/api/chat", async (req, res) => {
  try {
    const { messages } = req.body ?? {};

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "Send a non-empty messages array." });
    }

    const contents = messages.map(({ role, content }) => ({
      role: role === "assistant" ? "model" : "user",
      parts: [{ text: String(content ?? "").slice(0, 12000) }]
    }));

    const response = await ai.models.generateContent({
      model,
      contents,
      config: {
        systemInstruction: STELLA_SYSTEM_PROMPT
      }
    });

    res.json({ reply: response.text || "I couldn't generate a reply." });
  } catch (error) {
    console.error("Chat request failed:", error);
    res.status(502).json({ error: "Stella could not reach Gemini." });
  }
});

// JPEG/PNG image analysis
app.post("/api/image", upload.single("image"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "Please attach a JPEG or PNG image." });
    }

    const prompt = req.body.prompt || "Explain what is shown in this image.";

    const response = await ai.models.generateContent({
  model,
  config: {
    systemInstruction: STELLA_SYSTEM_PROMPT
  },
  contents: [{
        role: "user",
        parts: [
          { text: prompt },
          {
            inlineData: {
              mimeType: req.file.mimetype,
              data: req.file.buffer.toString("base64")
            }
          }
        ]
      }]
    });

    res.json({ reply: response.text || "I couldn't analyse this image." });
  } catch (error) {
    console.error("Image analysis failed:", error);
    res.status(502).json({ error: "Stella could not analyse the image." });
  }
});

// Serve the built frontend
const distPath = path.resolve(__dirname, "../dist");
app.use(express.static(distPath));

app.get("/{*splat}", (req, res, next) => {
  res.sendFile(path.join(distPath, "index.html"), err => err && next(err));
});

// Upload errors
app.use((error, req, res, next) => {
  console.error(error.message);
  res.status(400).json({ error: error.message });
});

app.listen(PORT, () => {
  console.log(`Stella server listening at http://localhost:${PORT}`);
});
