
import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  ArrowUp, AudioLines, BookOpen, Check, ChevronDown, CircleHelp,
  Headphones, Mic, MicOff, Moon, Plus, Sparkles, Volume2, VolumeX, X
} from 'lucide-react';
import './styles.css';

const welcome = {
  role: 'assistant',
  content: "Hey, I'm Stella ✨\n\nYour study companion is here. Ask me about a topic, paste a question, or tap the microphone and speak naturally.\n\nWhat are we learning today?"
};

function App() {
  const [messages, setMessages] = useState([welcome]);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);

  const [voices, setVoices] = useState([]);
  const [selectedVoice, setSelectedVoice] = useState('');
  const [speechRate, setSpeechRate] = useState(1);
  const [speechPitch, setSpeechPitch] = useState(1.1);

  const [voiceNotice, setVoiceNotice] = useState('');
  const [apiState, setApiState] = useState('checking');
  const [showSettings, setShowSettings] = useState(false);

  const bottomRef = useRef(null);
  const recognitionRef = useRef(null);
  const inputRef = useRef(null);

  // Check backend connection.
  useEffect(() => {
    fetch('/api/health')
      .then(response => {
        setApiState(response.ok ? 'online' : 'offline');
      })
      .catch(() => {
        setApiState('offline');
      });

    return () => {
      try {
        recognitionRef.current?.stop();
      } catch {}
    };
  }, []);

  // Keep the latest message visible.
  useEffect(() => {
    bottomRef.current?.scrollIntoView({
      behavior: 'smooth',
      block: 'end'
    });
  }, [messages, busy]);

  // Load voices available on this device.
  // This only retrieves voice information. It does not play audio.
  useEffect(() => {
    if (!('speechSynthesis' in window)) {
      setVoiceNotice('Voice selection is not supported in this browser.');
      return;
    }

    const loadVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();

      setVoices(availableVoices);

      if (availableVoices.length > 0 && !selectedVoice) {
        const preferredVoice = availableVoices.find(voice =>
          /female|zira|samantha|aria|jenny|susan|hazel/i.test(voice.name)
        );

        setSelectedVoice(
          (preferredVoice || availableVoices[0]).name
        );
      }
    };

    loadVoices();

    window.speechSynthesis.addEventListener(
      'voiceschanged',
      loadVoices
    );

    return () => {
      window.speechSynthesis.removeEventListener(
        'voiceschanged',
        loadVoices
      );
    };
  }, []);

  // Send a message to Gemini.
  const send = async (textOverride) => {
    const content = (textOverride ?? draft).trim();

    if (!content || busy) return;

    const next = [
      ...messages,
      { role: 'user', content }
    ];

    setMessages(next);
    setDraft('');
    setBusy(true);
    setVoiceNotice('');

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messages: next
            .filter(message =>
              message.role === 'user' ||
              message.role === 'assistant'
            )
            .slice(-12)
            .map(({ role, content }) => ({
              role,
              content
            }))
        })
      });

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(
          data.error ||
          `Request failed (HTTP ${response.status}).`
        );
      }

      setMessages(current => [
        ...current,
        {
          role: 'assistant',
          content: data.reply
        }
      ]);

      // Audio playback is intentionally disabled here.
      // Later, we will send speech audio to Stella's ESP32 speaker.
    } catch (error) {
      setMessages(current => [
        ...current,
        {
          role: 'error',
          content: `${error.message || 'Something went wrong.'}\n\nYour message is still in this chat. Check the backend/API setup, then try again.`
        }
      ]);
    } finally {
      setBusy(false);
      inputRef.current?.focus();
    }
  };

  // Browser microphone input.
  const startListening = () => {
    const SpeechRecognition =
      window.SpeechRecognition ||
      window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setVoiceNotice(
        'Voice input is not supported in this browser. Try Chrome or type your message.'
      );
      return;
    }

    if (listening) {
      recognitionRef.current?.stop();
      setListening(false);
      return;
    }

    const recognition = new SpeechRecognition();

    recognition.lang = 'en-IN';
    recognition.continuous = true;
    recognition.interimResults = true;

    recognitionRef.current = recognition;

    let finalText = '';

    recognition.onstart = () => {
      setListening(true);
      setVoiceNotice('Listening on your device…');
    };

    recognition.onresult = (event) => {
      let interim = '';

      for (
        let i = event.resultIndex;
        i < event.results.length;
        i++
      ) {
        const transcript = event.results[i][0].transcript;

        if (event.results[i].isFinal) {
          finalText += transcript;
        } else {
          interim += transcript;
        }
      }

      setDraft((finalText + interim).trimStart());
    };

    recognition.onerror = (event) => {
      setListening(false);

      setVoiceNotice(
        event.error === 'not-allowed'
          ? 'Microphone permission was blocked. Allow microphone access in your browser settings.'
          : 'Voice input stopped. You can try again or type your message.'
      );
    };

    recognition.onend = () => {
      setListening(false);

      setVoiceNotice(
        finalText
          ? 'Voice captured — review it, then send.'
          : ''
      );

      if (finalText.trim()) {
        setDraft(finalText.trim());
      }
    };

    try {
      recognition.start();
    } catch {
      setListening(false);
      setVoiceNotice('Could not start microphone. Try again.');
    }
  };

  // Start a new conversation.
  const newChat = () => {
    try {
      recognitionRef.current?.stop();
    } catch {}

    setListening(false);
    setMessages([welcome]);
    setDraft('');
    setVoiceNotice('');
  };

  return (
    <div className="app-shell">

      <aside className="sidebar">

        <div className="brand">
          <div className="brand-mark">
            <Sparkles size={20} strokeWidth={1.8} />
          </div>

          <div>
            <div className="brand-name">
              stella<span>.</span>
            </div>
            <div className="brand-sub">
              YOUR STUDY COMPANION
            </div>
          </div>
        </div>

        <button
          className="new-chat"
          onClick={newChat}
        >
          <Plus size={17} />
          New conversation
        </button>

        <div className="sidebar-label">
          YOUR SPACE
        </div>

        <div className="nav-item active">
          <BookOpen size={17} />
          <span>Study chat</span>
          <span className="nav-dot" />
        </div>

        <div className="sidebar-note">
          <div className="note-icon">
            <Sparkles size={16} />
          </div>

          <div className="note-title">
            One topic at a time.
          </div>

          <p>
            Ask questions, explore rabbit holes, and make difficult ideas click.
          </p>
        </div>

        <div className="sidebar-bottom">

          <div className={`connection ${apiState}`}>
            <span className="status-dot" />

            <span>
              {apiState === 'online'
                ? 'Backend connected'
                : apiState === 'checking'
                  ? 'Checking backend…'
                  : 'Backend unavailable'}
            </span>
          </div>

          <button
            className="settings-button"
            onClick={() => setShowSettings(value => !value)}
          >
            <CircleHelp size={17} />
            Voice & connection
            <ChevronDown
              size={15}
              className={showSettings ? 'rotate' : ''}
            />
          </button>

          {showSettings && (
            <div className="settings-panel">

              <div className="settings-row">
                <span>Voice output</span>
                <span>Not connected</span>
              </div>

              <p>
                Stella's browser audio playback is disabled.
                Her spoken replies will be routed to the physical
                speaker after the ESP32 audio connection is implemented.
              </p>

              <div className="voice-settings">

                <h3>Stella's voice</h3>

                <label htmlFor="stella-voice">
                  Choose a voice
                </label>

                <select
                  id="stella-voice"
                  value={selectedVoice}
                  onChange={event =>
                    setSelectedVoice(event.target.value)
                  }
                >
                  {voices.length === 0 && (
                    <option value="">
                      Loading available voices…
                    </option>
                  )}

                  {voices.map(voice => (
                    <option
                      key={`${voice.name}-${voice.lang}`}
                      value={voice.name}
                    >
                      {voice.name} — {voice.lang}
                    </option>
                  ))}
                </select>

                <label>
                  Speaking speed: {speechRate.toFixed(1)}
                </label>

                <input
                  type="range"
                  min="0.7"
                  max="1.3"
                  step="0.1"
                  value={speechRate}
                  onChange={event =>
                    setSpeechRate(Number(event.target.value))
                  }
                />

                <label>
                  Voice pitch: {speechPitch.toFixed(1)}
                </label>

                <input
                  type="range"
                  min="0.8"
                  max="1.5"
                  step="0.1"
                  value={speechPitch}
                  onChange={event =>
                    setSpeechPitch(Number(event.target.value))
                  }
                />

                <p>
                  These settings are saved for this session.
                  Audio preview is disabled until Stella's speaker
                  connection is ready.
                </p>

              </div>

              <p>
                Voice input uses your device's browser microphone.
                AI replies require a configured Gemini backend.
              </p>

            </div>
          )}

          <div className="profile">
            <div className="avatar">S</div>

            <div className="profile-text">
              <strong>Stella</strong>
              <span>Curious minds welcome</span>
            </div>

            <Moon size={17} className="moon" />
          </div>

        </div>
      </aside>

      <main className="main-panel">

        <header className="topbar">

          <div className="mobile-brand">
            <div className="brand-mark small">
              <Sparkles size={16} />
            </div>

            <strong>
              stella<span>.</span>
            </strong>
          </div>

          <div className="chat-title">
            <span className="online-indicator" />
            Study chat
            <span className="top-divider">/</span>
            <span className="muted">
              Your personal learning space
            </span>
          </div>

          <button
            className="top-icon"
            title="Voice settings"
            onClick={() => setShowSettings(value => !value)}
          >
            <VolumeX size={18} />
          </button>

        </header>

        <section className="conversation">

          <div className="date-chip">
            <span />
            A LITTLE SPACE TO THINK
            <span />
          </div>

          <div className="messages">

            {messages.map((message, index) => (
              <div
                className={`message-row ${message.role}`}
                key={`${index}-${message.role}`}
              >

                {message.role !== 'user' && (
                  <div
                    className={`message-avatar ${
                      message.role === 'error'
                        ? 'error-avatar'
                        : ''
                    }`}
                  >
                    {message.role === 'error'
                      ? <CircleHelp size={17} />
                      : <Sparkles size={17} />}
                  </div>
                )}

                <div className="message-content">

                  {message.role !== 'user' && (
                    <div className="message-author">
                      {message.role === 'error'
                        ? 'Connection note'
                        : 'Stella'}

                      <span>
                        {message.role === 'error'
                          ? 'SETUP'
                          : 'STUDY BUDDY'}
                      </span>
                    </div>
                  )}

                  <div className={`bubble ${message.role}`}>
                    <div className="message-text">
                      {message.content}
                    </div>
                  </div>

                </div>

                {message.role === 'user' && (
                  <div className="user-avatar">Y</div>
                )}

              </div>
            ))}

            {busy && (
              <div className="message-row assistant">

                <div className="message-avatar">
                  <Sparkles size={17} />
                </div>

                <div className="message-content">

                  <div className="message-author">
                    Stella <span>THINKING</span>
                  </div>

                  <div className="bubble typing">
                    <i />
                    <i />
                    <i />
                  </div>

                </div>
              </div>
            )}

            <div ref={bottomRef} />

          </div>
        </section>

        <footer className="composer-area">

          {(voiceNotice || listening) && (
            <div className={`voice-status ${listening ? 'listening' : ''}`}>
              <span className="status-dot" />

              {voiceNotice || 'Listening on your device…'}

              {listening && <AudioLines size={15} />}

              {!listening && (
                <button
                  onClick={() => setVoiceNotice('')}
                  aria-label="Dismiss notice"
                >
                  <X size={14} />
                </button>
              )}
            </div>
          )}

          <div className="composer">

            <textarea
              ref={inputRef}
              rows="1"
              value={draft}
              onChange={event => setDraft(event.target.value)}
              placeholder="Ask Stella anything you're curious about…"
              onKeyDown={event => {
                if (
                  event.key === 'Enter' &&
                  !event.shiftKey
                ) {
                  event.preventDefault();
                  send();
                }
              }}
            />

            <div className="composer-actions">

              <div className="composer-hint">
                <span className="keycap">↵</span>
                {' '}to send
                <span className="hint-divider">·</span>
                <span className="keycap">⇧ ↵</span>
                {' '}new line
              </div>

              <div className="action-buttons">

                <button
                  className={`mic-button ${listening ? 'recording' : ''}`}
                  onClick={startListening}
                  title={
                    listening
                      ? 'Stop listening'
                      : 'Use your microphone'
                  }
                >
                  {listening
                    ? <MicOff size={18} />
                    : <Mic size={18} />}
                </button>

                <button
                  className="send-button"
                  disabled={!draft.trim() || busy}
                  onClick={() => send()}
                  title="Send message"
                >
                  {busy
                    ? <span className="send-spinner" />
                    : <ArrowUp size={19} />}
                </button>

              </div>
            </div>
          </div>

          <div className="composer-caption">
            <Headphones size={13} />
            Microphone for voice input
            <span>·</span>
            Physical speaker integration planned
          </div>

        </footer>
      </main>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
